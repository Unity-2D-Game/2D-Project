using System.Collections;
using UnityEngine;

public class ReloadUI : MonoBehaviour
{
    public GameObject reloadImage;   
    public float reloadTime = 3f;    
    public float blinkTime = 0.5f;   

    private bool isReloading = false;

    void Start()
    {
        reloadImage.SetActive(false);
    }

    public void StartReload()
    {
        if (!isReloading)
        {
            StartCoroutine(ReloadRoutine());
        }
    }

    IEnumerator ReloadRoutine()
    {
        isReloading = true;

        float timer = 0f;

        while (timer < reloadTime)
        {
            reloadImage.SetActive(true);
            yield return new WaitForSeconds(blinkTime);

            reloadImage.SetActive(false);
            yield return new WaitForSeconds(blinkTime);

            timer += blinkTime * 2f;
        }

        reloadImage.SetActive(false);
        isReloading = false;
    }
}