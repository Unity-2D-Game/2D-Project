using UnityEngine;
using UnityEngine.UI;

public class SoundManager : MonoBehaviour
{
    public AudioSource bgmSource;
    public Image radioImage;

    private bool isSoundOn = true;

    void Start()
    {
        isSoundOn = true;
        bgmSource.Play();
        radioImage.color = new Color(1f, 1f, 1f, 1f);
    }

    public void ToggleSound()
    {
        isSoundOn = !isSoundOn;

        if (isSoundOn)
        {
            bgmSource.UnPause();
            radioImage.color = new Color(1f, 1f, 1f, 1f);
        }
        else
        {
            bgmSource.Pause();
            radioImage.color = new Color(1f, 1f, 1f, 0.5f);
        }
    }
}